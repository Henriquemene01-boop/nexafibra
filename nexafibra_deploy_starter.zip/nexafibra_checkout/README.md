# NexaFibra — deploy starter (Render)

A starter backend for an authorized, transparent checkout. It is **not payment-ready** and does not prove payments received. Use provider test credentials first.


## Deploy to Render (guided)
1. Put this folder in a Git repository you control and push it to GitHub.
2. In Render, choose **New → Blueprint** and connect that repository. Render reads `render.yaml`.
3. In the service environment settings, set `MP_ACCESS_TOKEN` to a Mercado Pago TEST access token and `SITE_URL` to your public HTTPS URL (no trailing slash).
4. Deploy. Wait for build to complete and visit `/health`; it should return `{ "ok": true, ... }`.
5. Test `POST /api/checkout` using a test account/token. Confirm it returns a sandbox checkout URL; use only the test payment methods.

## Local run
- Node.js 18+ (20 recommended).
- Copy `.env.example` to `.env`, fill test token and local `SITE_URL`.
- Run `npm install` then `npm start`.
- Health check: `GET http://localhost:3000/health`
- Create test checkout: `POST http://localhost:3000/api/checkout` with JSON `{}`.

## Before any real payment launch
- Connect checkout to authenticated customer records and actual invoice IDs; validate ownership server-side.
- Implement provider webhook signature verification, idempotency, and payment status reconciliation. Redirects are not proof of payment.
- Configure proper privacy policy, data retention, logging/monitoring, abuse prevention, and secure session/CSRF handling.
- Use HTTPS and production credentials only after account verification and test approval.
- Do not collect/store card data on this app; use hosted checkout.
